ACCESS
You can access the project using Live Server Plugin for VS Studio Code pressing "alt l alt o" in the opened index.html file.
