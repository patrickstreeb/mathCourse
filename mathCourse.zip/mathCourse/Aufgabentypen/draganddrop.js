// --- Shuffle helper ---
function shuffleElements(parentSelector) {
    const parent = document.querySelector(parentSelector);
    if (!parent) return;
  
    const elements = Array.from(parent.children);
    for (let i = elements.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [elements[i], elements[j]] = [elements[j], elements[i]];
    }
  
    elements.forEach(el => parent.appendChild(el)); // Re-append in shuffled order
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    // Shuffle cards on page load
    shuffleElements('.card-pool');
  
    const cards = document.querySelectorAll('.card');
    const dropzones = document.querySelectorAll('.dropzoneContainer');
    let draggedCard = null;
  
    cards.forEach(card => {
      card.addEventListener('dragstart', e => {
        draggedCard = e.target;
        setTimeout(() => { draggedCard.style.display = 'none'; }, 0);
      });
  
      card.addEventListener('dragend', e => {
        draggedCard.style.display = 'block';
      });
    });
  
    dropzones.forEach(zone => {
      zone.addEventListener('dragover', e => e.preventDefault());
      zone.addEventListener('dragenter', e => zone.classList.add('active'));
      zone.addEventListener('dragleave', e => zone.classList.remove('active'));
      zone.addEventListener('drop', e => {
        e.preventDefault();
        if (draggedCard) {
          zone.appendChild(draggedCard);
          draggedCard.classList.add('placed');
          draggedCard.style.display = 'block';
          zone.classList.remove('active');
          draggedCard = null;
        }
      });
    });
  
    // Check answer logic
    window.checkAnswers = function () {
      let correct = 0;
      const total = cards.length;
  
      cards.forEach(card => {
        const zone = card.closest('.dropzoneContainer');
  
        card.classList.remove('correct', 'wrong');
        if (!zone) return;
  
        if (card.dataset.category === zone.dataset.category) {
          card.classList.add('correct');
          correct++;
        } else {
          card.classList.add('wrong');
        }
      });
  
      const feedbackElement = document.getElementById('feedback');
      const existingContent = feedbackElement.innerHTML;
      const resultMessage = `✅ ${correct} von ${total} richtig!`;
      feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;
  
      document.getElementById('feedback-banner').style.display = 'block';
    };
  });
  