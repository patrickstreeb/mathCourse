let draggedItem = null;

// Shuffle children inside a container
function shuffleContainer(selector) {
  const container = document.querySelector(selector);
  if (!container) return;

  const elements = Array.from(container.children);
  for (let i = elements.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [elements[i], elements[j]] = [elements[j], elements[i]];
  }
  elements.forEach(el => container.appendChild(el));
}

// DOM ready
document.addEventListener("DOMContentLoaded", () => {
  // Shuffle .image-card and .card elements
  shuffleContainer('.grid-container_1');
  shuffleContainer('.card-pool_1');

  // --- Drag logic ---
  document.querySelectorAll('.card_1').forEach(item => {
    item.addEventListener('dragstart', () => {
      draggedItem = item;
      item.classList.add('dragging');
    });

    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      draggedItem = null;
    });
  });

  // --- Dropzones ---
  document.querySelectorAll('.dropzone_1').forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());

    zone.addEventListener('drop', () => {
      if (!zone.querySelector('.card_1') && draggedItem) {
        zone.appendChild(draggedItem);
        draggedItem.classList.remove('dragging');
        draggedItem.classList.add('dropped');
      }
    });
  });
});

// --- Answer check logic ---
function checkAnswers() {
  let correct = 0;
  let total = 0;

  document.querySelectorAll('.dropzone_1').forEach(zone => {
    const card = zone.querySelector('.card_1');
    const container = zone.closest('.image-card_1');

    if (card && container) {
      const given = card.dataset.term;
      const expected = zone.dataset.correct;

      if (given === expected) {
        container.style.backgroundColor = '#d0f0c0'; // green
        correct++;
      } else {
        container.style.backgroundColor = '#f9c0c0'; // red
      }
    } else if (container) {
      container.style.backgroundColor = ''; // reset
    }
    total++;
  });

  const feedbackElement = document.getElementById('feedback');
  const existingContent = feedbackElement.innerHTML;
  const resultMessage = `✅ ${correct} von ${total} richtig!`;
  feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;

  document.getElementById('feedback-banner').style.display = 'block';
}





