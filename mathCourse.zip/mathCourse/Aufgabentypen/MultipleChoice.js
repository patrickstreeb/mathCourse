let selectedAnswer = null;
let answerIsCorrect = false;

function checkAnswer(isCorrect, clickedButton) {
  document.querySelectorAll('.answerbutton').forEach(btn => {
    btn.classList.remove('selected');
  });

  clickedButton.classList.add('selected');
  selectedAnswer = clickedButton;
  answerIsCorrect = isCorrect;
}

function checkAnswers() {
  if (!selectedAnswer) return;

  const buttons = document.querySelectorAll('.answerbutton');
  const correctButton = Array.from(buttons).find(btn =>
    btn.onclick.toString().includes('checkAnswer(true')
  );

  // Disable further clicking
  buttons.forEach(btn => btn.onclick = null);

  // Show feedback banner
  document.getElementById('feedback-banner').style.display = 'block';
  const feedbackElement = document.getElementById('feedback');
  const existingContent = feedbackElement.innerHTML;
  const resultMessage = answerIsCorrect ? "✅ Richtig!" : "❌ Falsch!";
  feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;
  

  if (!answerIsCorrect) {
    selectedAnswer.classList.add("wrong");

    // Blink correct answer before marking it correct
    correctButton.classList.add("blinking");
    setTimeout(() => {
      correctButton.classList.remove("blinking");
      correctButton.classList.add("correct");
    }, 2 * 200); // 3 blinks × 0.5s
  } else {
    selectedAnswer.classList.add("correct");
  }
}
