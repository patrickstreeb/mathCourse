function toggleTooltip(id) {
    const tooltip = document.getElementById(id);
    const isVisible = tooltip.style.display === 'block';
    document.querySelectorAll('.tooltip').forEach(t => t.style.display = 'none');
    if (!isVisible) tooltip.style.display = 'block';
  }

  document.addEventListener('click', function(event) {
    if (!event.target.closest('th.hoverable')) {
      document.querySelectorAll('.tooltip').forEach(t => t.style.display = 'none');
    }
  });

function checkTable() {
  const inputs = document.querySelectorAll('tbody input');
  let correct = 0;
  const total = inputs.length;

  inputs.forEach(input => {
    const userValue = parseFloat(input.value.replace(',', '.'));
    const correctValue = parseFloat(input.dataset.correct);

    if (!isNaN(userValue) && Math.abs(userValue - correctValue) < 0.01) {
      input.classList.add('correct');
      input.classList.remove('wrong');
      correct++;
    } else {
      input.classList.add('wrong');
      input.classList.remove('correct');
    }
  });

  // Show feedback
  const feedbackElement = document.getElementById('feedback');
  const existingContent = feedbackElement.innerHTML;
  const resultMessage = `✅ ${correct} von ${total} richtig!`;
  feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;

  document.getElementById('feedback-banner').style.display = 'block';
}
