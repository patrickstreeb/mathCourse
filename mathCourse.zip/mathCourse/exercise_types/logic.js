let currentQuiz = 0;
const quizBoxes = document.querySelectorAll('[id^="quiz-"]');
const totalQuizzes = quizBoxes.length;

// Progress bar setup
const toolbar = document.querySelector('.progress-toolbar');
for (let i = 0; i < totalQuizzes; i++) {
  const dot = document.createElement('div');
  dot.className = 'progress-dot';
  toolbar.appendChild(dot);
  if (i < totalQuizzes - 1) {
    const line = document.createElement('div');
    line.className = 'progress-line';
    toolbar.appendChild(line);
  }
}

// DRAG AND DROP FUNCTIONALITY
function initDragAndDrop() {
  document.querySelectorAll('.card_1').forEach(card => {
    card.addEventListener('dragstart', e => {
      e.dataTransfer.setData('text/plain', card.dataset.term);
      e.dataTransfer.effectAllowed = 'move';
      card.classList.add('dragging');
    });

    card.addEventListener('dragend', () => {
      card.classList.remove('dragging');
    });
  });

  document.querySelectorAll('.dropzone_1').forEach(zone => {
    zone.addEventListener('dragover', e => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });

    zone.addEventListener('drop', e => {
      e.preventDefault();
      const term = e.dataTransfer.getData('text/plain');
      const draggedCard = document.querySelector(`.card_1.dragging[data-term="${term}"]`);
      if (!draggedCard) return;

      // Remove any existing card from dropzone and return it to pool
      const existing = zone.querySelector('.card_1');
      if (existing) {
        const pool = zone.closest('.box').querySelector('.card-pool_1');
        if (pool) pool.appendChild(existing);
      }

      zone.appendChild(draggedCard);
    });
  });
}

// FEEDBACK AND CHECKING
function checkAnswers() {
  const zones = document.querySelectorAll(`#quiz-${currentQuiz} .dropzone_1`);
  let correct = 0;
  let total = zones.length;

  zones.forEach(zone => {
    const card = zone.querySelector('.card_1');
    const expected = zone.dataset.correct;
    const given = card?.dataset.term;

    const container = zone.closest('.image-card_1');
    if (given === expected) {
      container.style.backgroundColor = '#d0f0c0';
      correct++;
    } else {
      container.style.backgroundColor = '#f9c0c0';
    }
  });

  const feedback = document.getElementById(`feedback-${currentQuiz}`);
  const banner = document.getElementById(`feedback-banner-${currentQuiz}`);
  if (feedback && banner) {
    feedback.textContent = `✅ ${correct} von ${total} richtig!`;
    banner.style.display = 'block';
  }

  // Progress bar update
  const dots = document.querySelectorAll('.progress-dot');
  const lines = document.querySelectorAll('.progress-line');
  if (dots[currentQuiz]) dots[currentQuiz].classList.add('active');
  if (lines[currentQuiz]) lines[currentQuiz].classList.add('active');
}

// NEXT QUIZ
function nextQuiz() {
  document.getElementById(`quiz-${currentQuiz}`).style.display = 'none';

  currentQuiz++;
  const nextBox = document.getElementById(`quiz-${currentQuiz}`);
  if (nextBox) {
    nextBox.style.display = 'block';
    MathJax.typeset();
  }
}

// INIT
document.addEventListener('DOMContentLoaded', () => {
  initDragAndDrop();
});
