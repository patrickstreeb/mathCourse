function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let draggedItem = null;

  document.addEventListener('DOMContentLoaded', () => {
    shuffle(terms);
    const termArea = document.getElementById('terms');
    terms.forEach(term => {
      const div = document.createElement('div');
      div.className = 'drag-item';
      div.draggable = true;
      div.textContent = term.text;
      termArea.appendChild(div);
    });
    setupDragDrop();
  });

  function setupDragDrop() {
    const termArea = document.getElementById('terms');

    document.querySelectorAll('.drag-item').forEach(item => {
      item.addEventListener('dragstart', () => {
        draggedItem = item;
        item.classList.add('dragging');
      });
      item.addEventListener('dragend', () => {
        draggedItem.classList.remove('dragging');
        draggedItem = null;
      });
    });

    document.querySelectorAll('.gapzone').forEach(zone => {
      zone.addEventListener('dragover', e => e.preventDefault());
      zone.addEventListener('drop', () => {
        if (!draggedItem) return;

        const current = zone.querySelector('.drag-item');
        const source = draggedItem.parentElement;

        if (current) {
          source.appendChild(current);
          current.classList.remove('correct', 'wrong', 'dropped');
        }

        zone.innerHTML = '';
        zone.appendChild(draggedItem);
        draggedItem.classList.add('dropped');
        draggedItem.classList.remove('correct', 'wrong');
      });
    });

    termArea.addEventListener('dragover', e => e.preventDefault());
    termArea.addEventListener('drop', () => {
      if (!draggedItem) return;
      const source = draggedItem.parentElement;
      if (source.classList.contains('gapzone')) {
        source.classList.remove('correct', 'wrong');
      }
      termArea.appendChild(draggedItem);
      draggedItem.classList.remove('dropped', 'correct', 'wrong');
    });
  }

  function checkAnswers() {
    let correct = 0;
    let total = 0;
  
    document.querySelectorAll('.gapzone').forEach(zone => {
      const item = zone.querySelector('.drag-item');
      const expected = zone.dataset.correct?.trim();
  
      if (item) {

        const actual = item.textContent.trim();
  
        if (actual === expected) {
          zone.classList.add('correct');
          zone.classList.remove('wrong');
          correct++;
        } else {
          zone.classList.add('wrong');
          zone.classList.remove('correct');
        }
      } else {
        zone.classList.add('wrong');
        zone.classList.remove('correct');
      }
      total++;
    });
  
;
    document.getElementById('feedback-banner').style.display = 'block';

    const feedbackElement = document.getElementById('feedback');
    const existingContent = feedbackElement.innerHTML;
    const resultMessage = `✅ ${correct} von ${total} richtig!`;
    feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;
    
  }
  













  