let draggedItem = null;


function shuffleElements(containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;
  
    const elements = Array.from(container.children);
    for (let i = elements.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [elements[i], elements[j]] = [elements[j], elements[i]];
    }
    elements.forEach(el => container.appendChild(el)); // apply new order
  }

  

function setupDragDrop() {
  const bank = document.getElementById('bank');

  document.querySelectorAll('.formula-card').forEach(card => {
    card.addEventListener('dragstart', () => {
      draggedItem = card;
      card.classList.add('dragging');
    });

    card.addEventListener('dragend', () => {
      card.classList.remove('dragging');
      draggedItem = null;
    });
  });

  document.querySelectorAll('.dropzoneField').forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());

    zone.addEventListener('drop', () => {
      if (!draggedItem) return;

      const existing = zone.querySelector('.formula-card');
      const source = draggedItem.parentElement;

      if (existing) {
        source.appendChild(existing);
        existing.classList.remove('correct', 'wrong', 'dropped');
      }
      
      // Always clean up draggedItem too
      draggedItem.classList.remove('correct', 'wrong', 'dropped');
      zone.appendChild(draggedItem);
      draggedItem.classList.add('dropped');
      draggedItem.classList.remove('correct', 'wrong');
      MathJax.typeset();
      
    });
  });

  bank.addEventListener('dragover', e => e.preventDefault());
  bank.addEventListener('drop', () => {
    if (!draggedItem) return;
    const source = draggedItem.parentElement;
    if (source.classList.contains('dropzoneField')) {
      source.classList.remove('correct', 'wrong');
    }
    bank.appendChild(draggedItem);
    draggedItem.classList.remove('dropped');
    draggedItem.classList.remove('correct', 'wrong');
    MathJax.typeset();
  });
}

function checkAnswers() {
    let correct = 0;
    let total = 0;
  
    document.querySelectorAll('.dropzoneField').forEach(zone => {
      const card = zone.querySelector('.formula-card');
  
      if (card) {
        if (card.dataset.answer === zone.dataset.correct) {
          zone.classList.remove('wrong');
          correct++;
        } else {
          zone.classList.add('wrong');
        }
      } else {
        zone.classList.remove('correct', 'wrong');
      }
      total++;
    });
  
    // Feedback banner logic
    const feedbackElement = document.getElementById('feedback');
    const existingContent = feedbackElement.innerHTML;
    const resultMessage = `✅ ${correct} von ${total} richtig!`;
    feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;
  
    document.getElementById('feedback-banner').style.display = 'block';
  }
  

document.addEventListener('DOMContentLoaded', () => {
  shuffleElements('#bank');      // Shuffle formula cards inside the bank
  setupDragDrop();               // Set up drag & drop logic
  MathJax.typeset();             // Render formulas
});
