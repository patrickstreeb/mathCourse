

    // --- Formeln (LaTeX) und Begriffe ---
    
    // --- Shuffle helper ---
    function shuffle(array) {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
    
    // --- Seite starten ---
    document.addEventListener('DOMContentLoaded', () => {
      const selectedFormulas = [...formulas];
      shuffle(selectedFormulas);
    
      const selected = selectedFormulas.slice(0, 4); // 4 zufällig
      const grid = document.getElementById('grid');
      const cards = document.getElementById('cards');

      selected.forEach((item, idx) => {
        // Formel-Karte
        const card = document.createElement('div');
        card.className = 'formula-card';
    
        const content = document.createElement('div');
        content.className = 'formula-content';
        content.innerHTML = `\\(${item.formula}\\)`;
    
        const dropzone2 = document.createElement('div');
        dropzone2.className = 'dropzone2';
        dropzone2.dataset.correct = item.card;
    
        card.appendChild(content);
        card.appendChild(dropzone2);
        grid.appendChild(card);
      });
    
// Create draggable cards separately and shuffle
const draggableCards = selected.map(item => {
  const button = document.createElement('div');
  button.className = 'card';
  button.draggable = true;
  button.dataset.card = item.card;
  button.textContent = item.card;
  return button;
});

shuffle(draggableCards); // Ensure different order than formulas

draggableCards.forEach(button => cards.appendChild(button));

    
      // MathJax neu rendern
      MathJax.typeset();
    
      setupDragDrop();
    });
    
    // --- Drag & Drop Logik ---
    function setupDragDrop() {
      let draggedItem = null;
    
      document.querySelectorAll('.card').forEach(item => {
        item.addEventListener('dragstart', () => {
          draggedItem = item;
          item.classList.add('dragging');
        });
        item.addEventListener('dragend', () => {
          draggedItem = null;
          item.classList.remove('dragging');
        });
      });
    
      document.querySelectorAll('.dropzone2').forEach(zone => {
        zone.addEventListener('dragover', e => e.preventDefault());
        zone.addEventListener('drop', e => {
          if (!zone.querySelector('.card') && draggedItem) {
            zone.appendChild(draggedItem);
            draggedItem.classList.remove('dragging');
            draggedItem.classList.add('dropped');
          }
        });
      });
    }
    
    // --- Antworten überprüfen ---
    function checkAnswers() {
      let correct = 0;
      let total = 0;
    
      document.querySelectorAll('.dropzone2').forEach(zone => {
        const item = zone.querySelector('.card');
    
        if (item) {
          total++;
          const isCorrect = item.dataset.card === zone.dataset.correct;
    
          zone.classList.remove('correct', 'wrong');
          if (isCorrect) {
            zone.classList.add('correct');
            correct++;
          } else {
            zone.classList.add('wrong');
          }
        } else {
          zone.classList.add('wrong');
          zone.classList.remove('correct');
        }
      });
    
      // Show feedback banner
      const feedbackBanner = document.getElementById('feedback-banner');
      const feedbackText = document.getElementById('feedback');
    
      if (feedbackBanner && feedbackText) {
        feedbackText.textContent = `✅ ${correct} von ${total} richtig!`;
        feedbackBanner.style.display = 'block';
    
        // Force correct position at bottom
        feedbackBanner.style.position = 'fixed';
        feedbackBanner.style.bottom = '0';
        feedbackBanner.style.left = '0';
        feedbackBanner.style.width = '100%';
        feedbackBanner.style.zIndex = '1000';
      }
    }
    