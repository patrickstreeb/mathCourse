let draggedCard = null;

document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll('.card');
  const zones = document.querySelectorAll('.dropzone');

  cards.forEach(card => {
    card.addEventListener('dragstart', e => {
      draggedCard = e.target;
      e.dataTransfer.effectAllowed = 'move';
      setTimeout(() => {
        card.style.display = 'none';
      }, 0);
    });

    card.addEventListener('dragend', e => {
      card.style.display = 'block';
      draggedCard = null;
    });
  });

  zones.forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());
    zone.addEventListener('drop', e => {
      e.preventDefault();
      if (draggedCard) {
        zone.appendChild(draggedCard);
        draggedCard.style.display = 'block';
        draggedCard = null;
      }
    });
  });
});
