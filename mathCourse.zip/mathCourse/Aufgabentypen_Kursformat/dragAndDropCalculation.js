
// shuffle helper
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// init
document.addEventListener('DOMContentLoaded', () => {
  shuffle(steps);
  const termArea = document.getElementById('terms');
  steps.forEach(step => {
    const div = document.createElement('div');
    div.className = 'drag-item';
    div.draggable = true;
    div.dataset.order = step.order;
    div.innerHTML = `\\(${step.formula}\\)`;
    termArea.appendChild(div);
  });

  setupDragDrop();
  MathJax.typeset();
});

// drag and drop
let draggedItem = null;

function setupDragDrop() {
  const termArea = document.getElementById('terms');

  document.querySelectorAll('.drag-item').forEach(item => {
    item.addEventListener('dragstart', () => {
      draggedItem = item;
      item.classList.add('dragging');
    });

    item.addEventListener('dragend', () => {
      draggedItem.classList.remove('dragging');
      draggedItem = null;
    });
  });

  // Dropzones - enable swap
  document.querySelectorAll('.dropzone').forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());

    zone.addEventListener('drop', () => {
      if (!draggedItem) return;

      const current = zone.querySelector('.drag-item');
      const source = draggedItem.parentElement;

  // if dropzone already has an item
  if (current) {
    source.appendChild(current);

    current.classList.remove('correct', 'wrong');

    if (source.id === 'terms') {
      // if returning to terms: clean up
      current.classList.remove('dropped');
    } else {
      // if swapping between dropzones: keep dropped styling
      current.classList.add('dropped');
    }
  }


      // drop into empty field
      zone.appendChild(draggedItem);
      draggedItem.classList.add('dropped');
      draggedItem.classList.remove('correct', 'wrong');
      MathJax.typeset();
    });
  });

  // Terms container - allow items to return
  termArea.addEventListener('dragover', e => e.preventDefault());

  termArea.addEventListener('drop', () => {
    if (!draggedItem) return;

    const source = draggedItem.parentElement;
    if (source.classList.contains('dropzone')) {
      source.classList.remove('correct', 'wrong');
    }

    termArea.appendChild(draggedItem);
    draggedItem.classList.remove('dropped');  // only remove here
    draggedItem.classList.add('drag-item'); // reset to original class
    draggedItem.classList.remove('correct', 'wrong');
    MathJax.typeset();
  });
}




// check correctness
function checkAnswers() {
    let correct = 0;
    let total = 0;
  
    document.querySelectorAll('.dropzone').forEach(zone => {
      const item = zone.querySelector('.drag-item');
  
      if (item) {
        const isCorrect = parseInt(item.dataset.order) === parseInt(zone.dataset.correct);
  
        // Reset previous state
        item.classList.remove('wrong');
        zone.classList.remove('wrong', 'correct');
  
        if (isCorrect) {
          zone.classList.add('correct');
          correct++;
        } else {
          zone.classList.add('wrong');
          item.classList.add('wrong'); // apply red color via CSS
        }
      } else {
        // If no item present, treat as wrong
        zone.classList.add('wrong');
        zone.classList.remove('correct');
      }
      total++;
    });
  
    // Show feedback banner
    const feedbackElement = document.getElementById('feedback');
    const existingContent = feedbackElement.innerHTML;
    const resultMessage = `✅ ${correct} von ${total} richtig!`;
    feedbackElement.innerHTML = `${resultMessage} ${existingContent}`;
  
    document.getElementById('feedback-banner').style.display = 'block';
  }
  