let currentQuiz = 0;
const totalQuizzes = document.querySelectorAll('.question-box').length;

function shuffleContainer(container) {
  const elements = Array.from(container.children);
  for (let i = elements.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [elements[i], elements[j]] = [elements[j], elements[i]];
  }
  elements.forEach(el => container.appendChild(el));
}



// Build the progress toolbar dynamically
const toolbar = document.querySelector('.progress-toolbar');
for (let i = 0; i < totalQuizzes; i++) {
  const dot = document.createElement('div');
  dot.classList.add('progress-dot');
  toolbar.appendChild(dot);
  if (i < totalQuizzes - 1) {
    const line = document.createElement('div');
    line.classList.add('progress-line');
    toolbar.appendChild(line);
  }
}

  // Feedback display and progress update
  function showFeedback(correct, total) {
    const quizBox = Array.from(document.querySelectorAll('.question-box'))
      .find(box => box.style.display !== 'none');
  
    if (!quizBox) return;
  
    const feedback = quizBox.querySelector('.feedback-banner div[id^="feedback"]');
    const banner = quizBox.querySelector('.feedback-banner');
  
    if (feedback && banner) {
      feedback.innerHTML = `✅ ${correct} von ${total} richtig!`;
      banner.style.display = 'block';
    }
  
  }
  
  
  // Shared checkAnswers function
  function checkAnswers() {
    const quizBox = Array.from(document.querySelectorAll('.question-box'))
    .find(box => box.style.display !== 'none');  
    const dropzones = quizBox.querySelectorAll('.dropzone_1');
    let correct = 0;
    let total = 0;
  
    dropzones.forEach(zone => {
      const card = zone.querySelector('.card_1');
      const container = zone.closest('.image-card_1');
      if (container) container.style.backgroundColor = ''; // reset
  
      if (card && zone.dataset.correct === card.dataset.term) {
        correct++;
        if (container) container.style.backgroundColor = '#d0f0c0';
      } else if (card) {
        if (container) container.style.backgroundColor = '#f9c0c0';
      }
      total++;
    });
  
    showFeedback(correct, total);
  }

  let draggedItem = null;

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.grid-container_1').forEach(shuffleContainer);
  document.querySelectorAll('.card-pool_1').forEach(shuffleContainer);
  setupDragAndDrop();
});


function setupDragAndDrop() {
  // Standard cards
  document.querySelectorAll('.card_1').forEach(item => {
    item.addEventListener('dragstart', () => {
      draggedItem = item;
      item.classList.add('dragging');
    });

    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      draggedItem = null;
    });
  });

  // Dropzones for image-matching type
  document.querySelectorAll('.dropzone_1').forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());

    zone.addEventListener('drop', () => {
      if (!draggedItem) return;

      const source = draggedItem.parentElement;
      const current = zone.querySelector('.card_1');

      if (current) {
        source.appendChild(current);
        current.classList.remove('correct', 'wrong', 'dropped');
      }

      zone.appendChild(draggedItem);
      draggedItem.classList.add('dropped');
      draggedItem.classList.remove('correct', 'wrong');
    });
  });

  document.querySelectorAll('.card-pool_1').forEach(pool => {
    pool.addEventListener('dragover', e => e.preventDefault());

    pool.addEventListener('drop', () => {
      if (!draggedItem) return;

      const source = draggedItem.parentElement;
      if (source.classList.contains('dropzone_1')) {
        source.classList.remove('correct', 'wrong');
      }

      pool.appendChild(draggedItem);
      draggedItem.classList.remove('dropped', 'correct', 'wrong');
    });
  });

  // 🔻 NEW: support for .card (used in quiz-3)
  document.querySelectorAll('.card').forEach(item => {
    item.addEventListener('dragstart', () => {
      draggedItem = item;
      item.style.opacity = '0.5';
    });

    item.addEventListener('dragend', () => {
      item.style.opacity = '1';
      draggedItem = null;
    });
  });

  document.querySelectorAll('.dropzoneContainer').forEach(zone => {
    zone.addEventListener('dragover', e => e.preventDefault());

    zone.addEventListener('drop', () => {
      if (!draggedItem) return;
      zone.appendChild(draggedItem);
      draggedItem.classList.add('placed');
      draggedItem = null;
    });
  });

  document.querySelectorAll('.card-pool-3').forEach(pool => {
    pool.addEventListener('dragover', e => e.preventDefault());

    pool.addEventListener('drop', () => {
      if (!draggedItem) return;
      pool.appendChild(draggedItem);
      draggedItem = null;
    });
  });


    // 🔻 NEW: support for gaptext-type drag-and-drop
    document.querySelectorAll('.drag-item').forEach(item => {
      item.addEventListener('dragstart', () => {
        draggedItem = item;
        item.classList.add('dragging');
      });
  
      item.addEventListener('dragend', () => {
        item.classList.remove('dragging');
        draggedItem = null;
      });
    });
  
    document.querySelectorAll('.gapzone').forEach(zone => {
      zone.addEventListener('dragover', e => e.preventDefault());
  
      zone.addEventListener('drop', () => {
        if (!draggedItem) return;
  
        const current = zone.querySelector('.drag-item');
        const pool = document.querySelector('.card-pool-gaptext');
        if (current && pool) pool.appendChild(current); // return old
  
        zone.appendChild(draggedItem);
        draggedItem = null;
      });
    });
  
    document.querySelectorAll('.card-pool-gaptext').forEach(pool => {
      pool.addEventListener('dragover', e => e.preventDefault());
  
      pool.addEventListener('drop', () => {
        if (!draggedItem) return;
        pool.appendChild(draggedItem);
        draggedItem = null;
      });
    });

    
    
}

