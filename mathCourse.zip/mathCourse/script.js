


let progress = 0;

// -------------- TIMER -------------- //
function updateTimeElapsed() {
    const hours = Math.floor(totalTimeElapsed / 3600);
    const minutes = Math.floor((totalTimeElapsed % 3600) / 60);
    const seconds = totalTimeElapsed % 60;
    const timeElapsedDisplay = `${hours}h ${minutes}m ${seconds}s`;

    const timeElementEndSummary = document.getElementById("totalTime");

    if (timeElementEndSummary) {
        timeElementEndSummary.textContent = timeElapsedDisplay;
    }
}


// -------------- NEXT BUTTON AND PAGE NAVIGATION -------------- //
const blocks = Array.from(document.querySelectorAll(".quizContainers"));
let remaining = [...blocks];

document.getElementById("summary").style.display = "none";

// The next two functions have to be seperated:
// 1. ShowNextBlock() is called immediately without delay
// 2. Next(button) is for buttons with a delay
function ShowNextBlock() {
    var blockToShow = remaining.splice(Math.floor(Math.random() * remaining.length), 1)[0];
    blocks.forEach(function(block) {
        block.style.display = (block === blockToShow) ? "block" : "none";
    });
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, blockToShow]);
}


function Next(delay = true) {
    // Progress bar
    progress += 100 / (blocks.length);
    const progressBar = document.getElementById('progressBar');
    const progressLabel = document.getElementById('progressLabel');
    progressBar.style.width = progress + "%";
    progressLabel.textContent = Math.floor(progress) + "%";

    function handleNextStep() {
        if (!remaining.length) {
            document.getElementById("summary").style.display = "block";
            blocks.forEach(function(block) {
                block.style.display = "none";
            });
            return;
        }
        ShowNextBlock();
    }

    if (delay) {
        setTimeout(handleNextStep, 2500);
    } else {
        handleNextStsep();
    }
}


// Hides all blocks initially without any user interaction
ShowNextBlock();




// -------------- MULTIPLE CHOICE AND YES NO QUESTION -------------- // 
function checkAnswer(userAnswer, button) {
    const container = button.closest(".quizContainers");  // ✅ Correct: find the local container
    const feedbackElement = container.querySelector(".feedback");
    const point = container.querySelector('.point');
    const answerButtons = container.querySelectorAll(".answerbutton");

    let points = 1;
    let currentscore = 0;

    if (userAnswer) {
        const correctImg = new Image();
        correctImg.src = '../../pictures/general/checkmark.png';
        correctImg.style.width = '30px';
        feedbackElement.insertBefore(correctImg, feedbackElement.firstChild);
        feedbackElement.style.backgroundColor = "rgb(204, 239, 204)";
        feedbackElement.style.border = "1px solid darkgreen";
        score += points;
        currentscore += points;
    } else {
        const wrongImg = new Image();
        wrongImg.src = '../../pictures/general/wrong-sign.png';
        wrongImg.style.width = '30px';
        feedbackElement.insertBefore(wrongImg, feedbackElement.firstChild);
        feedbackElement.style.backgroundColor = "rgb(247, 172, 172)";
        feedbackElement.style.border = "1px solid darkred";
    }

    point.textContent = currentscore + "/";
    feedbackElement.style.display = "block";  // ✅ Show feedback immediately
    document.getElementById('totalScore').textContent = score;

    answerButtons.forEach(answerButton => {
        answerButton.style.display = "none";  // ✅ Hide all answer buttons after checking
    });
}







// -------------- TYPE IN NUMBER QUESTION TYPE -------------- //
let score = 0;

function checkAnswer2(button) {
    const container = button.closest(".quizContainers");  // <--- Fix: get local container
    const feedbackElement = container.querySelector(".feedback");
    const correctAnswer = container.querySelector(".solution").innerHTML.trim();
    const userAnswer = container.querySelector(".input-box").value.trim();
    const Answers = container.querySelector(".answers");

    let point = container.querySelector('.point');
    let pointss = 1;
    let currentscore = 0;

    if (userAnswer === correctAnswer) {
        const correctImg = new Image();
        correctImg.src = '../../pictures/general/checkmark.png';
        correctImg.style.width = '30px';
        feedbackElement.insertBefore(correctImg, feedbackElement.firstChild);
        feedbackElement.style.backgroundColor = "rgb(204, 239, 204)";
        feedbackElement.style.border = "1px solid darkgreen";
        score += pointss;
        currentscore += pointss;
    } else {
        const wrongImg = new Image();
        wrongImg.src = '../../pictures/general/wrong-sign.png';
        wrongImg.style.width = '30px';
        feedbackElement.insertBefore(wrongImg, feedbackElement.firstChild);
        feedbackElement.style.backgroundColor = "rgb(247, 172, 172)";
        feedbackElement.style.border = "1px solid darkred";
    }

    point.textContent = currentscore + "/";
    feedbackElement.style.display = "block";  // <--- Feedback will now correctly show
    Answers.style.display = "none";            // <--- Hide the input and button
    document.getElementById('totalScore').textContent = score;
}













// Fills in the gaps with the selected answer when a button is clicked
// for gaptexts
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".answer-buttons .button").forEach(button => {
        button.addEventListener("click", function () {
            const container = button.closest(".quizContainers");
            const gaps = container.querySelectorAll(".gap");
            const answer = button.getAttribute("data-answer");

            const firstEmptyGap = Array.from(gaps).find(gap => gap.textContent.trim() === "");
            if (firstEmptyGap) {
                firstEmptyGap.textContent = answer;
                MathJax.Hub.Queue(["Typeset", MathJax.Hub, firstEmptyGap]);
            }

            // Enable check-answer button when a gap is filled
            const checkBtn = container.querySelector(".check-answer");
            if (checkBtn) checkBtn.disabled = false;
        });
    });
});






// -------------- GAP TEXT QUESTION TYPE FUNCTIONALITY -------------- //
document.addEventListener("DOMContentLoaded", function () {
    let activeGap = null;

    blocks.forEach(container => {
        const gaps = container.querySelectorAll('.gap');
        const answerButtons = container.querySelectorAll('.answer-buttons .button');
        const checkAnswerButton = container.querySelector('.check-answer');
        const feedback = container.querySelector('.feedback');
        const gapc = container.querySelector('.gapcount');
        let deleteLastGapButton = container.querySelector('.deleteButton');
        let point = container.querySelector('.point');
        let pointss = 1;

        checkAnswerButton.disabled = gaps.length === 0;

        // Gap-Klick
        gaps.forEach(gap => {
            gap.addEventListener('click', () => {
                activeGap = gap;
            });
        });

        // Antwortbutton Klick
        answerButtons.forEach(button => {
            button.addEventListener('click', () => {
                const selectedLatex = button.innerHTML.trim(); 
                const selectedPlain = button.getAttribute('data-answer').trim();
                const selectedGap = activeGap || Array.from(gaps).find(gap => !gap.hasAttribute('data-user-answer'));

                if (selectedGap) {
                    selectedGap.innerHTML = selectedLatex;
                    selectedGap.setAttribute('data-user-answer', selectedPlain);
                    MathJax.Hub.Queue(["Typeset", MathJax.Hub, selectedGap]);
                    activeGap = null;
                }

                checkAnswerButton.disabled = false;
            });
        });

        // Check Answer
        checkAnswerButton.addEventListener('click', () => {
            let gapCount = 0;
            let currentscore = 0;

            gaps.forEach(gap => {
                const userAnswer = gap.getAttribute('data-user-answer')?.trim() || '';
                const correctAnswer = gap.getAttribute('data-answer')?.trim() || '';

                if (userAnswer === correctAnswer) {
                    gap.classList.remove('wrong-gap');
                    gap.classList.add('correct-gap');
                    score += pointss;
                    currentscore += pointss;
                } else {
                    gap.classList.remove('correct-gap');
                    gap.classList.add('wrong-gap');
                }

                gapCount += pointss;
            });

            feedback.style.display = "block";
            answerButtons.forEach(answerButton => answerButton.style.display = "none");
            if (deleteLastGapButton) deleteLastGapButton.style.display = "none";

            point.textContent = `${currentscore}/`;
            gapc.textContent = `${gapCount} ${gapCount > 1 ? "Points" : "Point"}`;
            document.getElementById('totalScore').textContent = score;

            const allCorrect = Array.from(gaps).every(gap => gap.classList.contains('correct-gap'));

            feedback.innerHTML = allCorrect
                ? '<span style="color:green;">All answers are correct!</span>'
                : '<span style="color:red;">Some answers are incorrect.</span>';

            MathJax.Hub.Queue(["Typeset", MathJax.Hub, feedback]);
            checkAnswerButton.style.display = "none";
        });

        // Delete Last Gap
        if (deleteLastGapButton) {
            deleteLastGapButton.addEventListener('click', () => {
                const lastFilledGap = Array.from(gaps).reverse().find(gap => gap.getAttribute('data-user-answer'));

                if (lastFilledGap) {
                    lastFilledGap.removeAttribute('data-user-answer');
                    lastFilledGap.innerHTML = '';
                    MathJax.Hub.Queue(["Typeset", MathJax.Hub, lastFilledGap]);
                }
            });
        }
    });
});



function checkTable() {
    const inputs = document.querySelectorAll('.table-input');
    let correct = 0;
    let total = inputs.length;
  
    inputs.forEach(input => {
      const userValue = parseFloat(input.value.replace(',', '.'));
      const correctValue = parseFloat(input.dataset.correct);
  
      if (!isNaN(userValue) && Math.abs(userValue - correctValue) < 0.01) {
        input.classList.add('correct');
        input.classList.remove('wrong');
        correct++;
      } else {
        input.classList.add('wrong');
        input.classList.remove('correct');
      }
    });
  
    const feedback = document.getElementById('feedback');
    feedback.innerHTML = `✅ ${correct} von ${total} richtig!`;
  }
  