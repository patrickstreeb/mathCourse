window.MathJax = {
    tex: {
      inlineMath: [['$', '$'], ['\\(', '\\)']],
      displayMath: [['$$', '$$'], ['\\[', '\\]']],
      tags: 'ams',
      macros: {
        sum: ['\\displaystyle\\sum', 0],
        int: ['\\displaystyle\\int', 0],
        prod: ['\\displaystyle\\prod', 0],
        lim: ['\\displaystyle\\lim', 0],
        frac: ['\\displaystyle\\frac', 2],
        sqrt: ['\\displaystyle\\sqrt', 1]
      }
    },
    chtml: {
      scale: 1.2,  // Increase the font size
      displayAlign: 'center'  // Center alignment for display math
    }
  };



document.addEventListener('DOMContentLoaded', () => {
    const startPoint = parseInt(localStorage.getItem('startPoint') || '1');
    const allBoxes = Array.from(document.querySelectorAll('.start-block'));
    const dots = document.querySelectorAll('.progress-dot');
    if (dots[currentIndex]) dots[currentIndex].classList.add('active');
    // Ensure that the start point directly matches the button order
    allBoxes.forEach((box, index) => {
      box.style.display = (index + 1 === startPoint) ? 'block' : 'none';
    });
  
    currentIndex = startPoint - 1;
    localStorage.removeItem('startPoint');
  
  });
  
  
  
  
  
      function showFeedbackPage() {
        const reached = sessionStorage.getItem('reachedPoints') || 0;
        const total = sessionStorage.getItem('totalPoints') || 0;
        const successRate = total > 0 ? Math.round((reached / total) * 100) : 0;
    
        // Anzeige der Werte
        document.getElementById('reached-points').innerText = reached;
        document.getElementById('total-points').innerText = total;
        document.getElementById('success-rate').innerText = successRate + '%';
    
        // Feedback-Nachricht
        const feedbackMessage = document.getElementById('feedback-message');
        if (successRate >= 80) {
          feedbackMessage.innerText = 'Super gemacht! Du hast eine ausgezeichnete Leistung gezeigt.';
          feedbackMessage.style.color = '#2a9d8f';
        } else if (successRate >= 50) {
          feedbackMessage.innerText = 'Gut gemacht! Es gibt noch etwas Verbesserungspotential.';
          feedbackMessage.style.color = '#f4a261';
        } else {
          feedbackMessage.innerText = 'Nicht schlecht! Übung macht den Meister. Versuche es noch einmal!';
          feedbackMessage.style.color = '#e76f51';
        }
    
        // Zeige die Feedback-Seite
        document.getElementById('feedback-page').style.display = 'block';
      }
    
    
      function updateScore(correct, total) {
        const currentReached = parseInt(sessionStorage.getItem('reachedPoints') || 0);
        const currentTotal = parseInt(sessionStorage.getItem('totalPoints') || 0);
        sessionStorage.setItem('reachedPoints', currentReached + correct);
        sessionStorage.setItem('totalPoints', currentTotal + total);
      }


document.addEventListener('DOMContentLoaded', () => {
    const firstTheoryBox = document.querySelector('.theory-block[style*="display: block"]');
    if (firstTheoryBox) {
      const firstUnit = firstTheoryBox.querySelector('.theory-unit');
      if (firstUnit) {
        firstUnit.style.display = 'block';
        firstUnit.classList.add('active');
        MathJax.typesetPromise([firstUnit]);
      }
    }
  
    document.querySelectorAll('.grid-container_1').forEach(shuffleContainer);
    document.querySelectorAll('.card-pool_1').forEach(shuffleContainer);
    document.querySelectorAll('.card-pool-gaptext').forEach(shuffleContainer);
    setupDragAndDrop();
  });
  
  
  let currentQuestion = 1;
  
  
  // make destinction if theory page is present or ecervise page 
  
  let currentIndex = 0;
  
  function NextQuestion() {
    const allBoxes = Array.from(document.querySelectorAll('.box'));
  
    // ✅ Progress update BEFORE index changes
    const dots = document.querySelectorAll('.progress-dot');
    const lines = document.querySelectorAll('.progress-line');
    if (dots[currentIndex]) dots[currentIndex + 1].classList.add('active');
    if (currentIndex > 0 && lines[currentIndex]) {
      lines[currentIndex].classList.add('active');
    }
  
    // Hide current box
    if (currentIndex < allBoxes.length) {
      allBoxes[currentIndex].style.display = 'none';
      currentIndex++;
    }
  
    // Show next box
    if (currentIndex < allBoxes.length) {
      const nextBox = allBoxes[currentIndex];
      nextBox.style.display = 'block';
  
      if (nextBox.classList.contains('question-box')) {
        nextBox.querySelectorAll('.grid-container_1').forEach(shuffleContainer);
        nextBox.querySelectorAll('.card-pool_1').forEach(shuffleContainer);
        nextBox.querySelectorAll('.card-pool-gaptext').forEach(shuffleContainer);
        setupDragAndDrop();
      }
  
      if (nextBox.classList.contains('theory-block')) {
        const units = nextBox.querySelectorAll('.theory-unit');
        if (units.length > 0) {
          units[0].style.display = 'block';
          units[0].classList.add('active');
          MathJax.typesetPromise([units[0]]);
        }
      }
  
      MathJax.typeset();
    }
  
    // ✅ Reset the flag to allow drag-and-drop again
    answersChecked = false;
  }
  
  
  
  function checkAnswers_2() {
    const quizBox = document.querySelector('.question-box:not([style*="display: none"])');
    if (!quizBox) return;
  
    const dropzones = quizBox.querySelectorAll('.dropzoneContainer');
    let correct = 0;
    let total = 0;
  
    dropzones.forEach(zone => {
      const expected = zone.dataset.category;
      const cards = zone.querySelectorAll('.card');
  
      cards.forEach(card => {
        card.classList.remove('correct', 'wrong'); // reset
        total++;
        if (card.dataset.category === expected) {
          card.classList.add('correct');
          correct++;
        } else {
          card.classList.add('wrong');
        }
      });
    });
  
    showFeedback(correct, total);
  }
  
  let answersChecked = false;
  
  
  function checkAnswers_3() {
    const quizBox = document.querySelector('.question-box:not([style*="display: none"])');
    if (!quizBox) return;
  
    const zones = quizBox.querySelectorAll('.gapzone');
    let correct = 0;
    let total = 0;
  
    zones.forEach(zone => {
      const item = zone.querySelector('.drag-item');
      const expected = zone.dataset.correct?.trim();
  
      if (item) {
        const actual = item.textContent.trim();
  
        if (actual === expected) {
          zone.classList.add('correct');
          zone.classList.remove('wrong');
          correct++;
        } else {
          zone.classList.add('wrong');
          zone.classList.remove('correct');
        }
      } else {
        zone.classList.add('wrong');
        zone.classList.remove('correct');
      }
  
      total++;
    });
  
    // Disable drag and drop after checking answers
    answersChecked = true;
  
    showFeedback(correct, total);
  }
  
  
  
  
  
  function nextTheoryUnit(theoryBoxId) {
    const box = document.getElementById(theoryBoxId);
    const units = box.querySelectorAll('.theory-unit');
  
    let currentCount = Array.from(units).filter(unit => unit.style.display === 'block').length;
  
    if (currentCount < units.length) {
      const nextUnit = units[currentCount];
      nextUnit.style.display = 'block';
      nextUnit.classList.add('active');
      MathJax.typesetPromise([nextUnit]);
    }
  
    // When all units are visible, show the feedback banner
    if (currentCount === units.length) {
      box.querySelector('.feedback-banner').style.display = 'block';
      box.querySelector('.primary-button').style.display = 'none';
    }
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  let currentQuiz = 0;
  const totalQuizzes = document.querySelectorAll('.box').length;
  
  function shuffleContainer(container) {
    const elements = Array.from(container.children);
    for (let i = elements.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [elements[i], elements[j]] = [elements[j], elements[i]];
    }
    elements.forEach(el => container.appendChild(el));
  }
  
  
  
  // Build the progress toolbar dynamically
  const toolbar = document.querySelector('.progress-toolbar');
  const allBlocks = Array.from(document.querySelectorAll('.box'));
  
  allBlocks.forEach((block, index) => {
    const dot = document.createElement('div');
  
    // Check if the current block is a start-block
    if (block.classList.contains('start-block')) {
      dot.style.width = '40px';
      dot.style.height = '40px';
      dot.style.margin = '8px';
      dot.classList.add('progress-dot', 'bigdot');
  
      // Extract the subsection number from the block ID or use a custom attribute
      const subsectionNumber = block.getAttribute('data-subsection') || `S${index + 1}`;
      dot.innerText = subsectionNumber;
      dot.style.display = 'flex';
      dot.style.alignItems = 'center';
      dot.style.justifyContent = 'center';
      dot.style.fontSize = '15px';
      dot.style.color = 'white'; // Customize color as needed
    } else {
      dot.style.width = '10px';
      dot.style.height = '10px';
      dot.style.margin = '5px';
      dot.classList.add('progress-dot');
    }
  
    toolbar.appendChild(dot);
  
    // Add line between dots if it's not the last block
    if (index < allBlocks.length - 1) {
      const line = document.createElement('div');
      line.classList.add('progress-line');
      toolbar.appendChild(line);
    }
  });
  
  
  
    // Feedback display and progress update
    function showFeedback(correct, total) {
      const quizBox = Array.from(document.querySelectorAll('.question-box'))
        .find(box => box.style.display !== 'none');
    
      if (!quizBox) return;
    
      const feedback = quizBox.querySelector('.feedback-banner div[id^="feedback"]');
      const banner = quizBox.querySelector('.feedback-banner');
    
      if (feedback && banner) {
        feedback.innerHTML = `✅ ${correct} von ${total} richtig!`;
        banner.style.display = 'block';
      }
    
    }
    
    
    // Shared checkAnswers function
    function checkAnswers() {
      const quizBox = Array.from(document.querySelectorAll('.question-box'))
      .find(box => box.style.display !== 'none');  
      const dropzones = quizBox.querySelectorAll('.dropzone_1');
      let correct = 0;
      let total = 0;
    
      dropzones.forEach(zone => {
        const card = zone.querySelector('.card_1');
        const container = zone.closest('.image-card_1');
        if (container) container.style.backgroundColor = ''; // reset
    
        if (card && zone.dataset.correct === card.dataset.term) {
          correct++;
          if (container) container.style.backgroundColor = '#d0f0c0';
        } else if (card) {
          if (container) container.style.backgroundColor = '#f9c0c0';
        }
        total++;
      });
    
      showFeedback(correct, total);
    }
  
    let draggedItem = null;
  
    document.addEventListener('DOMContentLoaded', () => {
      let startPoint = localStorage.getItem('startPoint');
  if (!startPoint) {
    if (document.querySelector('.start-block[data-subsection="1"]')) {
      startPoint = '1';
    } else if (document.querySelector('.start-block[data-subsection="2"]')) {
      startPoint = '2';
    } else if (document.querySelector('.start-block[data-subsection="3"]')) {
      startPoint = '3';
    }
  }
  
    const targetBlock = document.querySelector(`.start-block[data-subsection="${startPoint}"]`);
    
    // Hide all blocks
    const allBoxes = Array.from(document.querySelectorAll('.start-block'));
    allBoxes.forEach((box) => {
      box.style.display = 'none';
    });
  
    // Show the target block
    if (targetBlock) {
      targetBlock.style.display = 'block';
    }
  
    currentIndex = parseInt(startPoint) - 1;
    localStorage.removeItem('startPoint');
  });
  
  
  
  function setupDragAndDrop() {
    // Standard cards
    document.querySelectorAll('.card_1').forEach(item => {
      item.addEventListener('dragstart', () => {
        draggedItem = item;
        item.classList.add('dragging');
      });
  
      item.addEventListener('dragend', () => {
        item.classList.remove('dragging');
        draggedItem = null;
      });
    });
  
    // Dropzones for image-matching type
    document.querySelectorAll('.dropzone_1').forEach(zone => {
      zone.addEventListener('dragover', e => e.preventDefault());
  
      zone.addEventListener('drop', () => {
        if (!draggedItem) return;
  
        const source = draggedItem.parentElement;
        const current = zone.querySelector('.card_1');
  
        if (current) {
          source.appendChild(current);
          current.classList.remove('correct', 'wrong', 'dropped');
        }
  
        zone.appendChild(draggedItem);
        draggedItem.classList.add('dropped');
        draggedItem.classList.remove('correct', 'wrong');
      });
    });
  
    document.querySelectorAll('.card-pool_1').forEach(pool => {
      pool.addEventListener('dragover', e => e.preventDefault());
  
      pool.addEventListener('drop', () => {
        if (!draggedItem) return;
  
        const source = draggedItem.parentElement;
        if (source.classList.contains('dropzone_1')) {
          source.classList.remove('correct', 'wrong');
        }
  
        pool.appendChild(draggedItem);
        draggedItem.classList.remove('dropped', 'correct', 'wrong');
      });
    });
  
    // 🔻 NEW: support for .card (used in quiz-3)
    document.querySelectorAll('.card').forEach(item => {
      item.addEventListener('dragstart', () => {
        draggedItem = item;
        item.style.opacity = '0.5';
      });
  
      item.addEventListener('dragend', () => {
        item.style.opacity = '1';
        draggedItem = null;
      });
    });
  
    document.querySelectorAll('.dropzoneContainer').forEach(zone => {
      zone.addEventListener('dragover', e => e.preventDefault());
  
      zone.addEventListener('drop', () => {
        if (!draggedItem) return;
        zone.appendChild(draggedItem);
        draggedItem.classList.add('placed');
        draggedItem = null;
      });
    });
  
    document.querySelectorAll('.card-pool').forEach(pool => {
      pool.addEventListener('dragover', e => e.preventDefault());
  
      pool.addEventListener('drop', () => {
        if (!draggedItem) return;
        pool.appendChild(draggedItem);
        draggedItem = null;
      });
    });
  
  
      // 🔻 NEW: support for gaptext-type drag-and-drop
      document.querySelectorAll('.drag-item').forEach(item => {
        item.addEventListener('dragstart', () => {
          draggedItem = item;
          item.classList.add('dragging');
        });
    
        item.addEventListener('dragend', () => {
          item.classList.remove('dragging');
          draggedItem = null;
        });
      });
    
      document.querySelectorAll('.gapzone').forEach(zone => {
    zone.addEventListener('dragover', e => {
      if (answersChecked) return;
      e.preventDefault();
    });
  
    zone.addEventListener('drop', () => {
      if (answersChecked || !draggedItem) return;
  
      const current = zone.querySelector('.drag-item');
      const pool = document.querySelector('.card-pool-gaptext');
  
      // If a current item exists, move it back to the pool and reset its classes
      if (current && pool) {
        pool.appendChild(current);
        current.classList.remove('dropped', 'correct', 'wrong');
      }
  
      // Move the dragged item to the gap
      zone.appendChild(draggedItem);
      draggedItem.classList.add('dropped');
      zone.classList.add('filled'); 
  
      draggedItem = null;
    });
  });
  
  document.querySelectorAll('.card-pool-gaptext').forEach(pool => {
    pool.addEventListener('dragover', e => {
      if (answersChecked) return;
      e.preventDefault();
    });
  
    pool.addEventListener('drop', () => {
      if (answersChecked || !draggedItem) return;
  
      const sourceZone = draggedItem.closest('.gapzone');
  
      // Remove the dropped class when the item is moved back to the pool
      draggedItem.classList.remove('dropped', 'correct', 'wrong');
  
      // Remove the "filled" class from the gap if the dragged item is from a gapzone
      if (sourceZone) {
        sourceZone.classList.remove('filled');
      }
  
      pool.appendChild(draggedItem);
      draggedItem = null;
    });
  });
  
  
  }