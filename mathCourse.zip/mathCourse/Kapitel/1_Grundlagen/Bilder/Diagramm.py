import matplotlib.pyplot as plt

# Daten: Anteil an vier Kategorien
labels = ['Kategorie A', 'Kategorie B', 'Kategorie C', 'Kategorie D']
sizes = [30, 25, 20, 25]
colors = ['#66b3ff', '#99ff99', '#ffcc99', '#ff6666']
explode = (0.05, 0.05, 0.05, 0.05)  # Alle leicht herausziehen

# Plot
plt.figure(figsize=(8, 8))
plt.pie(sizes, explode=explode, colors=colors,
        autopct='%1.1f%%', startangle=140, shadow=True)
plt.axis('equal')
plt.tight_layout()

# Anzeigen oder speichern
plt.show()
# plt.savefig("tortendiagramm_aufgabe.png")




import matplotlib.pyplot as plt

# Daten zur Browsernutzung
browser = ['Chrome', 'Firefox', 'Edge', 'Safari', 'Sonstige']
nutzung = [48, 22, 15, 10, 5]

# Stilvoll gestaltetes Balkendiagramm
fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.bar(browser, nutzung, width=0.6, edgecolor='black')

# Farbverlauf über Balken
for bar in bars:
    bar.set_facecolor('#4a90e2')
    bar.set_alpha(0.85)

# Achsentitel und Diagrammtitel
ax.set_title('Verteilung der Browsernutzung (Umfrage 2025)', fontsize=16, weight='bold', pad=20)
ax.set_xlabel('Browser', fontsize=12)
ax.set_ylabel('Anteil in %', fontsize=12)

# Gitterlinien und Layout
ax.yaxis.grid(True, linestyle='--', linewidth=0.5)
ax.set_axisbelow(True)
ax.set_ylim(0, 60)

# Balkenbeschriftungen
for bar in bars:
    yval = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2, yval + 1, f'{yval}%', ha='center', va='bottom', fontsize=10)

# Entferne oberen und rechten Rahmen
for spine in ['top', 'right']:
    ax.spines[spine].set_visible(False)

plt.tight_layout()
plt.show()
